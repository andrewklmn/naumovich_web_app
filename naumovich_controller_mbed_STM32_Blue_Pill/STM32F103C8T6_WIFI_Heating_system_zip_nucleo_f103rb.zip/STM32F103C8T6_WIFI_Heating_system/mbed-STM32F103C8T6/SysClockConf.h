#pragma once
void confSysClock(void);